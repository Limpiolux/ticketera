-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-09-2023 a las 16:45:47
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ticketreact`
--
CREATE DATABASE IF NOT EXISTS `ticketreact` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ticketreact`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `casa`
--

DROP TABLE IF EXISTS `casa`;
CREATE TABLE IF NOT EXISTS `casa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `sectores` text NOT NULL,
  `subsectores` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `casa`
--

INSERT INTO `casa` (`id`, `nombre`, `sectores`, `subsectores`) VALUES
(1, 'Toyota', '', ''),
(2, 'Limpiolux', 'Baño,Primer Piso', 'Subsector 1,Subsector 2'),
(3, 'Otra casa', 'prueba 1', '1,2,3,4');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tickets`
--

DROP TABLE IF EXISTS `tickets`;
CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `creador` int(11) DEFAULT NULL,
  `casa` int(11) DEFAULT NULL,
  `prioridad` enum('Baja','Media','Alta','Crítica') DEFAULT NULL,
  `estado` enum('Abierto','Cerrado','En progreso') DEFAULT NULL,
  `asunto` varchar(255) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `archivos_adjuntos` longtext DEFAULT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `visible_cliente` tinyint(1) DEFAULT NULL,
  `tracking_id` varchar(50) NOT NULL,
  `sector` varchar(255) NOT NULL,
  `subsector` varchar(255) NOT NULL,
  `comentarios` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`comentarios`)),
  PRIMARY KEY (`id`),
  KEY `creador` (`creador`),
  KEY `casa` (`casa`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tickets`
--

INSERT INTO `tickets` (`id`, `creador`, `casa`, `prioridad`, `estado`, `asunto`, `descripcion`, `archivos_adjuntos`, `fecha_vencimiento`, `visible_cliente`, `tracking_id`, `sector`, `subsector`, `comentarios`) VALUES
(79, 1, 3, 'Crítica', 'Cerrado', 'parte critica', 'hola', 'data:image/gif;base64,R0lGODlh9QHIAaIAAMzM3cfH2sTE176+07290rm50P4BAgAAACH5BP0UAAYALAAAAAD1AcgBQAP/CLrc/jDKSau9OOvNu/9gKI5kaZ5oqq5s675wLM90bd9iIAhD4f/AoHBILBqPyKTSOGgGAriodEqtwnSEpXbL7Xq/4DDYaS2bz+hAT8xuu9/wuJxNIEDR+Lx5Pe/7/0JNO3d6Ek87TYBtAwKFjo8PAoqTlEMChJCZH1iVBY2aoCSSnaRuA6GooTxzn6mOWaWxW62utbYgArBitLcourLAQ6e9xMU2fF3DxhDIwc6Yy9HSZ6NcvI7VzsDX093eoQG/SdwzAdrB3+nq6eFLdinZ553r9BQ6zfJxgtDE8UbkE8TlA6SsXj+BAxPKYYTNiAR8CufwM6jHXMRxAHtxGjOR/8pFghTxIEzYMeSJXEsyloD40ZTJKSO1lXyJR82Rghta+lFJM0VMYDN7LmtHhBxLnWJwCoVHcqnTBz0YHEUKhudTDj9LBb3KdSrVL1xJDFQatmyDr3LMevCHTq3bB1nRWnubYSzduwvYyq2Kl4JXUlv7OtW7F6xgZnYP3y0MR7GDuKQc07XIuI1VtZTzSaZb+U1gtRE3uyXcmQvZvhEJiDZLuvSsza23rQ7r+s3mzAo/z2ZX241qybgVnt5NL3hvMLrDxj6XnHix5ceXNO/69bdzddCjKxmO13jLd9enQda+hHvfvxfNh8/knTzf3URLq19/Br37LfMFZ5c7YDr9F//j3Yfff/EJGARD/8Gwn4Fa5CeaTQzOIcgOlzxhoSEWHsJDE1PRtGCEWlx2HUoghhZWgSXG4R99EKY4x2EouqjPiglSsEOA0V3XnoxyiFjjj0vZx2McPgJpJD0fDsnKkUy+lKSSlPTX5JTTPAnlOWRQqSUkVl7pGodPFHejYVs+0qKXaKJZ5jRnpulmbWteReKbdJ4TJ3Fz1qknGHf2mVeee0Lp56ApHCJkoH0wQiOhjKqT4aOQRvpoo5RWaumUGVK4IYeJhMHphBRmeOmoQwGKqDb7kOqnDqe2WkSWqlLUpqu0AkNAkbG2cGitPig62z27LoRrrDsiimCuHGyU6KL/I7o6LLI2rGIKs0vhmCK10Noi7Xse0ulgtpMF+wO2VXQZHbng7vYheGdY6x666W45KxMymOsavPFmYCGFnwr5qaYXcpXdt4ZcSXCu8/La67NTZBeUvZ1lC7FwjFwSg4adynGrGQVG4O5xlcb4EcP1KJtSFB/XdjCLLZEcnqmWmDBxYfKmlm8EUzlYrIFNzmzbzSSILJWSLt+1c2RA1yCuyjUOZF3SNfgsV9FlpSwh1FJIjdbKbi19NdZSHC0g1U4lBnbWBsNn9tlRiD32bFZ/zbYUXvdG9kt1Lzk33Wjia1DcfeyNNpp3yxqR34JrkDfIm6WXeLRvIr7OR1w/DgLg/9E9DeN3lsewuHaiYQ5S5yxo/aVonyuiOemi7Ln6Yab7IXnibvNY+VOxAzI72KkLuDuS8v0Obu7nOkd8KYVnKzqIt6vV+0UW7/08iMLTNH1lsFoqsrNMHq9wEE8tT/Sa236vxWTipx0yzHSudj3hc+uwIVKpAum9l8mznu37p+av/6W1M195/Pe/PvFPgK+qXgFZlD4EviF767nHDxY4AfY50Fv9OuCLKJgDDV7wgw7hIA0SBsISJkGEmbCgCWmFwnVIcIVDaiFwVAhDO8mQVBjzIPZ8dcMe+vCHQAyiEIdIxCJ2LocMAlWYjIi1F9YQCfVjYnhM9sRgQFCKJdNhFf9lUQcFYrEEJNyim3bwxXqJUYzHKiMGwnjGBoFqEJNa46M0tSktUmJjX7xfmqLYE0PZMURepNT2BHirQDrFiZ3AI9gCWKfo5YuKfSAgff5YG0WKEJIuidMg6SRJ0rGxC50M0qmap0YF0DBEoQuUIdVYvi+E0hYNrM0rS8mBUxqBXSGhJFJWScsR2LIo6eBkL6XxJFJSgZG+GyZFkmRMGbiJl8rUQ7BmyQFdCieafVlQMz8AP2yuZj+4XIEeHefN/wgpnCIYp4l6KD9reoFDjsROeXChvschEoPQREF2ilTPpP3yglfMw3L8AqVtUkmdhKSmByAygSshzJ36iKcjgDX/rXL5IALI7I1BI1gYiYYEk0mQkkWVlE+1IPQLIhXNPwuQ0hicVB6DymglNoqXVhYhlDK9lyYpN6pT3g1KJe0JRJHwuv0dYVhDtaKWXkrUzk1FJTktTVANElW9cZAwvGCqM4pKH63edIjIGNqQaFoWrxKhl0mVzY8SosyC1sisQlCo4NIKjATRNQhT9SdQuzqQclYVexzNh1wtd9dY5NUYhZ1gOQHw18qEZ23ehGtdnQNZbya2FM65bAEWywAv4Wkgg2Wdlw5ri6ZwVgGx3Nqv2HpaBWgWaSo17WklCwyyliwhtpVhNxsnW87SFiioU0hrFZAm0qJinZxtbGlCawzk/y72t2p1jHLhwFzCukk0FzEu1F5r2M1w96K+fdNtPqLdm013ubAZ2WKFKZnv+oCrrKRTeTPh3l55s5HpbUluWQddVI1XJ/BlYn1jEVukVDdpqUWvd79y4HwFyn1oaTC4ArVfecplvpRK8OlWo+E+oPOHA67tahkjYe2dKsDdUXAPO1wbDIcixFCU4XndU+F69JcjFISxM0psjBsnxcXr0fEzpsji2gKZw7w6cip8zAol30XI2uBxlaDUxVxBWRsoXs0nlVSHQVjByWAUoJTTceUY5hKBY3ZUmQUklBm7KM02LnKdBPbBGk9mpbUaTQnh3GY8pymbK+TziWzqUMcwGf+wj0QEm38lZx4JGkj74tenkkCAf4VqiXE6tCyHa8A2shTMnJbGmhnT0lAbadQqNvVbPX0TUKtaE1tm9adfTZxNypoIaaS1YGx965C6Wtc4QLWbAgpsk/i510nh4WRAqtgWahrZP1Cii3OoQSIeG9rILuWzse2i5zaa29dVdazBrbBiO2Dc5G6fuS+A7nSnaN2+/La7YQrvFuxg3qCrd9sIjW/h6nui/O73JP4djXsKHD8eJThN2nnGiil8VfLbFKkrVqGHW/ziGM+4xjfO8Y57/OMgD7nIR05y/WlI4t+BJxxLfic/YtAJv2b5FFz+RD7K3IUBB7fNbw7rawu8yzH/73jOD26KhPP8BGoQ9hmrfHQPtJvoW/1w000pb6grItcj97nVC4N1i2t969opdbGVDvZJdH2xTy87nSzZy7RvsQ63qpBxIz2/wrC9iNsmT8WC3gGMUY7vNeL1BYFuNINHd4F554/R4VP3WIh9bmTHEuCHknRSPD5fkd/G5D/69QZt3noIvPzNhm6ZWCVesBS8904a5WYBiV6EpH/n522ReUA8+lKxnwuTWq+d2w9veq//ZqvsLMPOR3v2Vaj6hfXt9phJRvlUIX582eD7MvA+1R+HWPVRpifpD7f5P9i+DKD/kSyXHPzB90btSz91G1nN+w1be/s30Hzxg+D6e7E//62Xln5QkD8383cSXqB/NhI5AVg6yTB5/zcQyAdvSUKAjPVMB3gDwQJ/1VRcEzhzu9J/M5AmEMhzeEZa+IcU5peBwfYakDNaJsglOMJc69cFJbiCZXAoCrWAMiGDtbAfoWSDzoCDxCB4PuA/XmKByIJEjkdxmCYrAXI3PHh4qZd79KNs3SAkzNKEstCARmN8nbFztWAfUhcQV4KFg2aFJHh3oGAf3/KCW8A2rFJDTKcJ9lEBp5cWSQN+DsSBYZMV9hCG+aKFK2SGX1YEFMCHElMibyQqFZApkvZHgDg4QDABangyueKHqLJ4N8BwcHB2FNhskeBWqqJ0UugKFLULx/8EX4V2KaP2gSPAbOOABpGoBGKIWPwRi6IgLo1YDlCiiukwh7q4b9aChyjwiifEKDAGjHexUqE1gtATUwZ2JONGTcKIBKuiE7SoCdDRSbnYci1RjbWwZckzh42xJsroSqaXFV+IAWTYCb3YC+7FjWQmjcmyV0tlM1jjFc0Bjj9DJen4AzFoVF9VAdH4D1QyjlvQj4n2Kg1FUlPiY+6oZ0SATgTJWkzyWkRIKUfBAPjoBk2yjwXQkIYmBBipJBUZEv42RNUgVrZzJLiFRZgQkAgJJPs4kkDjksD0I5olkzM5PquWDzgJNBw5Cev4CBLZSz95dTWyj9hEk8KQIBHZitH/pJRDkCBImZSCwjKoh00Z2QYeeQx95U1NeZWPBZbYRGWBJQ9bySRFqQhnaUaasVhQGVfhcVk9eTZZ2QZhKQ9zeTaESByV9ZSeyJc8OVt7ORt9GU39tBpDWU51yQZr6QKa1VpfGZjqwoCt9ZZC0JgIKJnJ5Vm7kZjlZJkHshuaFZSWooLC15WCeYrYBVrDNYSzcWPDtZjUR5isWZmmmV/5gJlMoiaI6ZmRxZu4iZfDBZogGVyFGU1pOQkGyRUKQZqVgiZ5mQqRiQTO2SiyyQbRiQo+Vp2Mcp1JUWC1yVnEGZoLtpKnlZyUYJzHOUzoOXDl6ZuG+WfvSZmcJYHtFRHc/zkoYxSc+bCcRTRs/Jmb9Rlu0kVO5WSAz5ddi9WeQDmfTrOg4gUc6mVZCOoYyamb/+GdixCgqKlMGqqVvHUR/vlD04mfHKqZwzRnm4Ge2Zku44lrJ4qi2lYnGLoSOtGi0FKi9JignEOU+CWhu0RLH+oGNdo6zVhKejKiokQ/pfSi/3ifVFGkQPqjUMqkX8SggKGeQSpFOiqiEFYdWOSkRaCkSwGOOCpIFKZl+WdEYvqSt4GlQJCf9GEss7FmctosaXqae3GmfQKnlrcbfgoE57hAXdqjetpRPjSkcUCmTyFsxjhXrSKlJlCo39lCgUoKd3oD3smnzugqnPpiGpV6rv/CqFdRe486erQiqcHYe6zTpk6ZWeRxi9tFK4OqGK8oq/lyqbGQqY54H5YILrpaCrWqGJQIParaC8GKPObkIqfqJ64qHRkqkrw6Dc+6HTUipl2Git8zrVVQrb3SH8caf98Trixgh4a4D17kd+C1iwJEruXqrR9xW+YzrKIJdiGRrCLWPfjqHngTegc1bz2hqDPlrhcDr+nZZvtqKwQrA+bKK6X6QQtLA8WqbldBqdgnLwI7WWVhsKZBKKzYKm+RsVpBKVAInG/BscnQUyIrBrsGQxGbBmOimucBQ5/qFvKTsErwpjXErSUzihsGnjDEs0thhKUwIUkYrVUktD4IiWL/pLRL+wBAiGZPWxyeVrNTG2ZV+7I3t7IJ4bRPy7UJgatXq53Q1qxjWxPcZrZna304S2peO4EoWwlvO39g+xWauLYCdXBqi7c0ELdGxreFULedUUiAewYNW7Vzm31qFwSEW7hR4Lf6tbeO23eQa7e/yiKJ6yFtWycw9yuEJqqLi52huHCGJ4goJLjDh6630E69k6ihiyqHiIj3p4h1RGBBNLGvC7JFdLi5eyplVLm92wW9hLvByyMUWrwCNFvAi7ybFWrEy7yuAWzPC71yUW/TS73xqnAli70Rk3G8y70dynHbC77OFXLXS750yHMfi749OIHjy75+sLTrC78bdLaVWEe/fzC5CjC/+LsE+hsB79u/zfu/iXi/AnxWBOx0jUe/Vtt0htK7o5vADKtoaUtGEtxzC/w9XHjB3UC0zLN3WsvB+nJydfRHnAIwRyvCKrzCLNzCLgxvCQAAOw==', '2023-09-28', 1, 'APY-869-APJ', 'prueba 1', '4', '[{\"Comentario\":\"hola como estan, necesito esto\",\"creador\":\"John Doe\",\"fecha\":\"8/9/2023, 15:31:51\"},{\"Comentario\":\"¿\\n\",\"creador\":\"John Doe\",\"fecha\":\"8/9/2023, 15:32:01\"},{\"Comentario\":\"1231231\",\"creador\":\"John Doe\",\"fecha\":\"8/9/2023, 15:32:13\"},{\"Comentario\":\"312231232131223\",\"creador\":\"John Doe\",\"fecha\":\"8/9/2023, 15:33:28\"},{\"Comentario\":\"1111\",\"creador\":\"John Doe\",\"fecha\":\"8/9/2023, 15:33:37\"},{\"Comentario\":\"como voy a resolver este ticket\",\"creador\":\"Mauricio\",\"fecha\":\"8/9/2023, 15:40:34\"},{\"Comentario\":\"se esta resolviendo! tengan paciencia\",\"creador\":\"John Doe\",\"fecha\":\"8/9/2023, 18:41:11\"}]'),
(80, 1, 2, 'Crítica', 'Abierto', 'Solicitud de insumos', '123', '', '2023-09-21', 1, 'PMB-658-RDP', 'Baño', 'Subsector 1', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `cargo` enum('supervisor','empleado','cliente') NOT NULL,
  `casa` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mail` (`mail`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `nombre`, `mail`, `contraseña`, `cargo`, `casa`) VALUES
(1, 'John Doe', 'johndoe@example.com', '$2b$10$v2gpFwctz7/uyDfrPJMfxe1VaOPFb.h9NcuuFabhDdTymCQlAyylC', 'supervisor', '2,3'),
(2, 'Mauricio', 'mauricio@example.com', '$2b$10$QfhvAv7cqLPDfgVFpLEdweB0khgCqA9ZuhzmBdKc9uIqqT34wnvne', 'cliente', '2, 3'),
(10, 'eloy', 'elo@example.com', '$2b$10$XtQ7KQEb3XTOxa7PwQ7F/.LU4bYbjpUdVdNFjb1ESQ7VRrGRFZfse', 'supervisor', '2,3'),
(11, 'Lucas Lujan', 'llujan@limpiolux.com.ar', '$2b$10$873mGhKU2ozt7qEZ68ltKux/C0HSjUDWrGYvKcQYVP0i0SCsw1sDq', 'supervisor', '2,3'),
(12, 'Javier Soto', 'jsoto@limpiolux.com.ar', '$2b$10$eRHHcjPDQxWHuKJWwXuF/uD.vddhn8LpueEAsi.JZS98P1rejSDNy', 'supervisor', '2,3'),
(13, 'Julian', 'jcallegari@limpiolux.com.ar', '$2b$10$yPWPtb4hTNk1JsNYFtJqguNG90AxMef8Z600SEH8L3psAaE9wS3G6', 'supervisor', '2,3');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`creador`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tickets_ibfk_2` FOREIGN KEY (`casa`) REFERENCES `casa` (`id`);


--
-- Metadatos
--
USE `phpmyadmin`;

--
-- Metadatos para la tabla casa
--

--
-- Metadatos para la tabla tickets
--

--
-- Volcado de datos para la tabla `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'ticketreact', 'tickets', '[]', '2023-09-01 18:27:40');

--
-- Metadatos para la tabla users
--

--
-- Metadatos para la base de datos ticketreact
--
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
